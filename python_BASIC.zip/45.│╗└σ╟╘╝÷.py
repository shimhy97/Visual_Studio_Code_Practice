#내장함수 : 프로그램 자체에 내장되어 있어 인풋 없이 바로 사용 가능한 함수

#dir : 어떤 객체를 넘겨줬을 때 그 객체가 어떤 변수와 함수를 가지고 있는지 표시!

# print(dir())
import random       # random은 외장 함수
# print(dir())        
# import pickle
# print(dir())

print(dir(random))

#구글에서 list of python buillitins 검색 ㄱㄱ