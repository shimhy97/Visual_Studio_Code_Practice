days = (1,2,3,4,5,6,7)
count = 0
# for i in days:
#     if count %2 == 0:
#         print(days[count])
#     else:
#         print("fuuck even num")
#     count +=1
# string도 엄연히 배열의 한 종류이다
a=0
for i in "SHIMHOONYONG": 
    print(i, end=" ")
    a +=1
    if a == len("SHIMHOONYONG"):
        print("")


from math import radians

print(radians(2))

직접 모듈 만들어서 import도 가능!   >> from 파일명(모듈명) import 함수혹은클래스명

requests.get 여기서 get은 메서드 이다. 객체 안에 있는 함수!

--------------


