data = enumerate([1, 2, 3])
print(data, type(data))

for i,value in data:
    print(i)