# + 로 이어진 부분에서 
# 정수 자료와 불리안 자료는 str()로 묶어줘야 한다.
# ex

age = 14
is_adult = True

print ("나이는 " + str(age) + "살이다.")
print ("어른인가? " + str(is_adult))