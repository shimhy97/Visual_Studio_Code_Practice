from random import *

name1 = randint(4,28)

print("오프라인 스터디 모임 날짜는 매월 " + str(name1) + "일로 선정되었습니다.")
print("오프라인 스터디 모임 날짜는 매월", name1 ,"일로 선정되었습니다.")
