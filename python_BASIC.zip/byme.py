class sign():
    def __init__(self):
        print("이 프로그램은 심훈용에 의해 만들어졌습니다.")
        print("유튜브 : http://youtube.com")
        print("이메일 : shimhy97@naver.com")